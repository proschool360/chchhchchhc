<?php
/**
 * Reports Controller
 * Handles HR analytics, dashboards, and various reports generation
 */

if (!defined('HRMS_ACCESS')) {
    define('HRMS_ACCESS', true);
}

require_once __DIR__ . '/../utils/Response.php';
require_once __DIR__ . '/../utils/Validator.php';
require_once __DIR__ . '/../config/database.php';

class ReportsController {
    private $db;
    private $user;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Set current user context
     */
    public function setUser($user) {
        $this->user = $user;
    }
    
    /**
     * Get HR dashboard data
     */
    public function getDashboard() {
        try {
            if (!in_array($this->user['role'], ['admin', 'hr', 'manager'])) {
                Response::forbidden('Access denied');
                return;
            }
            
            $params = Router::getQueryParams();
            $year = $params['year'] ?? date('Y');
            $month = $params['month'] ?? date('m');
            
            // Employee statistics
            $employeeStats = $this->getEmployeeStatistics($year, $month);
            
            // Attendance statistics
            $attendanceStats = $this->getAttendanceStatistics($year, $month);
            
            // Leave statistics
            $leaveStats = $this->getLeaveStatistics($year, $month);
            
            // Payroll statistics
            $payrollStats = $this->getPayrollStatistics($year, $month);
            
            // Recruitment statistics
            $recruitmentStats = $this->getRecruitmentStatistics($year, $month);
            
            // Performance statistics
            $performanceStats = $this->getPerformanceStatistics($year);
            
            // Training statistics
            $trainingStats = $this->getTrainingStatistics($year, $month);
            
            // Recent activities
            $recentActivities = $this->getRecentActivities();
            
            // Alerts and notifications
            $alerts = $this->getHRAlerts();
            
            $dashboard = [
                'period' => [
                    'year' => $year,
                    'month' => $month,
                    'month_name' => date('F', mktime(0, 0, 0, $month, 1))
                ],
                'employee_statistics' => $employeeStats,
                'attendance_statistics' => $attendanceStats,
                'leave_statistics' => $leaveStats,
                'payroll_statistics' => $payrollStats,
                'recruitment_statistics' => $recruitmentStats,
                'performance_statistics' => $performanceStats,
                'training_statistics' => $trainingStats,
                'recent_activities' => $recentActivities,
                'alerts' => $alerts
            ];
            
            Response::success($dashboard);
            
        } catch (Exception $e) {
            Response::serverError('Failed to fetch dashboard data: ' . $e->getMessage());
        }
    }
    
    /**
     * Get employee headcount report
     */
    public function getHeadcountReport() {
        try {
            if (!in_array($this->user['role'], ['admin', 'hr', 'manager'])) {
                Response::forbidden('Access denied');
                return;
            }
            
            $params = Router::getQueryParams();
            $year = $params['year'] ?? date('Y');
            $groupBy = $params['group_by'] ?? 'department'; // department, position, gender, age_group
            
            // Current headcount
            $currentHeadcount = $this->db->selectOne(
                "SELECT COUNT(*) as total FROM employees WHERE status = 'active'"
            );
            
            // Headcount by group
            $headcountByGroup = [];
            
            switch ($groupBy) {
                case 'department':
                    $headcountByGroup = $this->db->select(
                        "SELECT d.name as group_name, COUNT(e.id) as count
                         FROM departments d
                         LEFT JOIN employees e ON d.id = e.department_id AND e.status = 'active'
                         GROUP BY d.id, d.name
                         ORDER BY count DESC"
                    );
                    break;
                    
                case 'position':
                    $headcountByGroup = $this->db->select(
                        "SELECT p.title as group_name, COUNT(e.id) as count
                         FROM positions p
                         LEFT JOIN employees e ON p.id = e.position_id AND e.status = 'active'
                         GROUP BY p.id, p.title
                         ORDER BY count DESC"
                    );
                    break;
                    
                case 'gender':
                    $headcountByGroup = $this->db->select(
                        "SELECT 
                            CASE 
                                WHEN gender = 'male' THEN 'Male'
                                WHEN gender = 'female' THEN 'Female'
                                ELSE 'Other'
                            END as group_name,
                            COUNT(*) as count
                         FROM employees 
                         WHERE status = 'active'
                         GROUP BY gender
                         ORDER BY count DESC"
                    );
                    break;
                    
                case 'age_group':
                    $headcountByGroup = $this->db->select(
                        "SELECT 
                            CASE 
                                WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) < 25 THEN 'Under 25'
                                WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) BETWEEN 25 AND 34 THEN '25-34'
                                WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) BETWEEN 35 AND 44 THEN '35-44'
                                WHEN TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) BETWEEN 45 AND 54 THEN '45-54'
                                ELSE '55+'
                            END as group_name,
                            COUNT(*) as count
                         FROM employees 
                         WHERE status = 'active' AND date_of_birth IS NOT NULL
                         GROUP BY group_name
                         ORDER BY count DESC"
                    );
                    break;
            }
            
            // Monthly headcount trend
            $monthlyTrend = $this->db->select(
                "SELECT 
                    MONTH(hire_date) as month,
                    COUNT(*) as hires,
                    (SELECT COUNT(*) FROM employees e2 
                     WHERE e2.termination_date IS NOT NULL 
                     AND MONTH(e2.termination_date) = MONTH(e1.hire_date)
                     AND YEAR(e2.termination_date) = ?) as terminations
                 FROM employees e1
                 WHERE YEAR(hire_date) = ?
                 GROUP BY MONTH(hire_date)
                 ORDER BY month",
                [$year, $year]
            );
            
            // Calculate net change for each month
            foreach ($monthlyTrend as &$trend) {
                $trend['net_change'] = $trend['hires'] - $trend['terminations'];
                $trend['month_name'] = date('F', mktime(0, 0, 0, $trend['month'], 1));
            }
            
            $report = [
                'current_headcount' => (int)$currentHeadcount['total'],
                'group_by' => $groupBy,
                'headcount_by_group' => $headcountByGroup,
                'monthly_trend' => $monthlyTrend,
                'year' => $year,
                'generated_at' => date('Y-m-d H:i:s')
            ];
            
            Response::success($report);
            
        } catch (Exception $e) {
            Response::serverError('Failed to generate headcount report: ' . $e->getMessage());
        }
    }
    
    /**
     * Get attrition report
     */
    public function getAttritionReport() {
        try {
            if (!in_array($this->user['role'], ['admin', 'hr', 'manager'])) {
                Response::forbidden('Access denied');
                return;
            }
            
            $params = Router::getQueryParams();
            $year = $params['year'] ?? date('Y');
            $period = $params['period'] ?? 'yearly'; // monthly, quarterly, yearly
            
            // Overall attrition statistics
            $totalEmployees = $this->db->selectOne(
                "SELECT COUNT(*) as total FROM employees WHERE YEAR(hire_date) <= ?",
                [$year]
            );
            
            $terminations = $this->db->selectOne(
                "SELECT COUNT(*) as total FROM employees 
                 WHERE termination_date IS NOT NULL AND YEAR(termination_date) = ?",
                [$year]
            );
            
            $attritionRate = $totalEmployees['total'] > 0 ? 
                round(($terminations['total'] / $totalEmployees['total']) * 100, 2) : 0;
            
            // Attrition by department
            $departmentAttrition = $this->db->select(
                "SELECT d.name as department_name,
                        COUNT(CASE WHEN e.termination_date IS NULL THEN 1 END) as active_employees,
                        COUNT(CASE WHEN YEAR(e.termination_date) = ? THEN 1 END) as terminations,
                        ROUND(
                            (COUNT(CASE WHEN YEAR(e.termination_date) = ? THEN 1 END) / 
                             NULLIF(COUNT(CASE WHEN e.termination_date IS NULL OR YEAR(e.termination_date) = ? THEN 1 END), 0)) * 100, 2
                        ) as attrition_rate
                 FROM departments d
                 LEFT JOIN employees e ON d.id = e.department_id
                 GROUP BY d.id, d.name
                 ORDER BY attrition_rate DESC",
                [$year, $year, $year]
            );
            
            // Attrition reasons
            $attritionReasons = $this->db->select(
                "SELECT 
                    COALESCE(termination_reason, 'Not Specified') as reason,
                    COUNT(*) as count,
                    ROUND((COUNT(*) / ?) * 100, 2) as percentage
                 FROM employees 
                 WHERE termination_date IS NOT NULL AND YEAR(termination_date) = ?
                 GROUP BY termination_reason
                 ORDER BY count DESC",
                [$terminations['total'] ?: 1, $year]
            );
            
            // Tenure analysis of terminated employees
            $tenureAnalysis = $this->db->select(
                "SELECT 
                    CASE 
                        WHEN TIMESTAMPDIFF(MONTH, hire_date, termination_date) < 6 THEN '0-6 months'
                        WHEN TIMESTAMPDIFF(MONTH, hire_date, termination_date) < 12 THEN '6-12 months'
                        WHEN TIMESTAMPDIFF(MONTH, hire_date, termination_date) < 24 THEN '1-2 years'
                        WHEN TIMESTAMPDIFF(MONTH, hire_date, termination_date) < 60 THEN '2-5 years'
                        ELSE '5+ years'
                    END as tenure_group,
                    COUNT(*) as count
                 FROM employees 
                 WHERE termination_date IS NOT NULL AND YEAR(termination_date) = ?
                 GROUP BY tenure_group
                 ORDER BY count DESC",
                [$year]
            );
            
            // Period-wise attrition trend
            $periodTrend = [];
            if ($period === 'monthly') {
                $periodTrend = $this->db->select(
                    "SELECT 
                        MONTH(termination_date) as period,
                        COUNT(*) as terminations
                     FROM employees 
                     WHERE termination_date IS NOT NULL AND YEAR(termination_date) = ?
                     GROUP BY MONTH(termination_date)
                     ORDER BY period",
                    [$year]
                );
                
                foreach ($periodTrend as &$trend) {
                    $trend['period_name'] = date('F', mktime(0, 0, 0, $trend['period'], 1));
                }
            }
            
            $report = [
                'overall_statistics' => [
                    'total_employees' => (int)$totalEmployees['total'],
                    'total_terminations' => (int)$terminations['total'],
                    'attrition_rate' => $attritionRate
                ],
                'department_attrition' => $departmentAttrition,
                'attrition_reasons' => $attritionReasons,
                'tenure_analysis' => $tenureAnalysis,
                'period_trend' => $periodTrend,
                'year' => $year,
                'period' => $period,
                'generated_at' => date('Y-m-d H:i:s')
            ];
            
            Response::success($report);
            
        } catch (Exception $e) {
            Response::serverError('Failed to generate attrition report: ' . $e->getMessage());
        }
    }
    
    /**
     * Get leave trends report
     */
    public function getLeaveTrendsReport() {
        try {
            if (!in_array($this->user['role'], ['admin', 'hr', 'manager'])) {
                Response::forbidden('Access denied');
                return;
            }
            
            $params = Router::getQueryParams();
            $year = $params['year'] ?? date('Y');
            
            // Overall leave statistics
            $overallStats = $this->db->selectOne(
                "SELECT 
                    COUNT(*) as total_requests,
                    COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved_requests,
                    COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected_requests,
                    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_requests,
                    SUM(CASE WHEN status = 'approved' THEN days_requested ELSE 0 END) as total_days_taken
                 FROM leave_requests 
                 WHERE YEAR(start_date) = ?",
                [$year]
            );
            
            // Leave by type
            $leaveByType = $this->db->select(
                "SELECT lt.name as leave_type,
                        COUNT(lr.id) as request_count,
                        SUM(CASE WHEN lr.status = 'approved' THEN lr.days_requested ELSE 0 END) as days_taken,
                        AVG(CASE WHEN lr.status = 'approved' THEN lr.days_requested ELSE NULL END) as avg_days_per_request
                 FROM leave_types lt
                 LEFT JOIN leave_requests lr ON lt.id = lr.leave_type_id AND YEAR(lr.start_date) = ?
                 GROUP BY lt.id, lt.name
                 ORDER BY days_taken DESC",
                [$year]
            );
            
            // Monthly leave trends
            $monthlyTrends = $this->db->select(
                "SELECT 
                    MONTH(start_date) as month,
                    COUNT(*) as requests,
                    SUM(CASE WHEN status = 'approved' THEN days_requested ELSE 0 END) as days_taken
                 FROM leave_requests 
                 WHERE YEAR(start_date) = ?
                 GROUP BY MONTH(start_date)
                 ORDER BY month",
                [$year]
            );
            
            foreach ($monthlyTrends as &$trend) {
                $trend['month_name'] = date('F', mktime(0, 0, 0, $trend['month'], 1));
            }
            
            // Department-wise leave analysis
            $departmentAnalysis = $this->db->select(
                "SELECT d.name as department_name,
                        COUNT(lr.id) as total_requests,
                        SUM(CASE WHEN lr.status = 'approved' THEN lr.days_requested ELSE 0 END) as total_days,
                        AVG(CASE WHEN lr.status = 'approved' THEN lr.days_requested ELSE NULL END) as avg_days_per_employee
                 FROM departments d
                 LEFT JOIN employees e ON d.id = e.department_id
                 LEFT JOIN leave_requests lr ON e.id = lr.employee_id AND YEAR(lr.start_date) = ?
                 GROUP BY d.id, d.name
                 ORDER BY total_days DESC",
                [$year]
            );
            
            // Top leave takers
            $topLeaveTakers = $this->db->select(
                "SELECT e.first_name, e.last_name, e.employee_id,
                        d.name as department_name,
                        COUNT(lr.id) as request_count,
                        SUM(CASE WHEN lr.status = 'approved' THEN lr.days_requested ELSE 0 END) as total_days
                 FROM employees e
                 LEFT JOIN departments d ON e.department_id = d.id
                 LEFT JOIN leave_requests lr ON e.id = lr.employee_id AND YEAR(lr.start_date) = ?
                 WHERE e.status = 'active'
                 GROUP BY e.id
                 HAVING total_days > 0
                 ORDER BY total_days DESC
                 LIMIT 10",
                [$year]
            );
            
            foreach ($topLeaveTakers as &$employee) {
                $employee['employee_name'] = $employee['first_name'] . ' ' . $employee['last_name'];
                unset($employee['first_name'], $employee['last_name']);
            }
            
            $report = [
                'overall_statistics' => [
                    'total_requests' => (int)$overallStats['total_requests'],
                    'approved_requests' => (int)$overallStats['approved_requests'],
                    'rejected_requests' => (int)$overallStats['rejected_requests'],
                    'pending_requests' => (int)$overallStats['pending_requests'],
                    'total_days_taken' => (int)$overallStats['total_days_taken'],
                    'approval_rate' => $overallStats['total_requests'] > 0 ? 
                        round(($overallStats['approved_requests'] / $overallStats['total_requests']) * 100, 2) : 0
                ],
                'leave_by_type' => $leaveByType,
                'monthly_trends' => $monthlyTrends,
                'department_analysis' => $departmentAnalysis,
                'top_leave_takers' => $topLeaveTakers,
                'year' => $year,
                'generated_at' => date('Y-m-d H:i:s')
            ];
            
            Response::success($report);
            
        } catch (Exception $e) {
            Response::serverError('Failed to generate leave trends report: ' . $e->getMessage());
        }
    }
    
    /**
     * Generate custom MIS report
     */
    public function generateMISReport() {
        try {
            if (!in_array($this->user['role'], ['admin', 'hr'])) {
                Response::forbidden('Access denied');
                return;
            }
            
            $data = Router::getRequestData();
            
            // Validate input
            $validator = Validator::make($data, [
                'report_type' => 'required|in:employee,attendance,payroll,leave,performance,recruitment,training',
                'date_from' => 'required|date',
                'date_to' => 'required|date',
                'format' => 'in:json,csv,pdf',
                'filters' => 'array'
            ]);
            
            if ($validator->fails()) {
                Response::validationError($validator->getErrors());
                return;
            }
            
            $reportType = $data['report_type'];
            $dateFrom = $data['date_from'];
            $dateTo = $data['date_to'];
            $format = $data['format'] ?? 'json';
            $filters = $data['filters'] ?? [];
            
            $reportData = [];
            
            switch ($reportType) {
                case 'employee':
                    $reportData = $this->generateEmployeeMISReport($dateFrom, $dateTo, $filters);
                    break;
                case 'attendance':
                    $reportData = $this->generateAttendanceMISReport($dateFrom, $dateTo, $filters);
                    break;
                case 'payroll':
                    $reportData = $this->generatePayrollMISReport($dateFrom, $dateTo, $filters);
                    break;
                case 'leave':
                    $reportData = $this->generateLeaveMISReport($dateFrom, $dateTo, $filters);
                    break;
                case 'performance':
                    $reportData = $this->generatePerformanceMISReport($dateFrom, $dateTo, $filters);
                    break;
                case 'recruitment':
                    $reportData = $this->generateRecruitmentMISReport($dateFrom, $dateTo, $filters);
                    break;
                case 'training':
                    $reportData = $this->generateTrainingMISReport($dateFrom, $dateTo, $filters);
                    break;
            }
            
            $report = [
                'report_type' => $reportType,
                'period' => [
                    'from' => $dateFrom,
                    'to' => $dateTo
                ],
                'filters_applied' => $filters,
                'data' => $reportData,
                'generated_at' => date('Y-m-d H:i:s'),
                'generated_by' => $this->user['first_name'] . ' ' . $this->user['last_name']
            ];
            
            if ($format === 'csv') {
                $this->downloadCSVReport($report);
            } else {
                Response::success($report);
            }
            
        } catch (Exception $e) {
            Response::serverError('Failed to generate MIS report: ' . $e->getMessage());
        }
    }
    
    // Helper methods for statistics
    
    private function getEmployeeStatistics($year, $month) {
        $stats = $this->db->selectOne(
            "SELECT 
                COUNT(CASE WHEN status = 'active' THEN 1 END) as active_employees,
                COUNT(CASE WHEN status = 'inactive' THEN 1 END) as inactive_employees,
                COUNT(CASE WHEN YEAR(hire_date) = ? AND MONTH(hire_date) = ? THEN 1 END) as new_hires,
                COUNT(CASE WHEN termination_date IS NOT NULL AND YEAR(termination_date) = ? AND MONTH(termination_date) = ? THEN 1 END) as terminations
             FROM employees",
            [$year, $month, $year, $month]
        );
        
        return [
            'active_employees' => (int)$stats['active_employees'],
            'inactive_employees' => (int)$stats['inactive_employees'],
            'new_hires' => (int)$stats['new_hires'],
            'terminations' => (int)$stats['terminations'],
            'net_change' => (int)$stats['new_hires'] - (int)$stats['terminations']
        ];
    }
    
    private function getAttendanceStatistics($year, $month) {
        $stats = $this->db->selectOne(
            "SELECT 
                COUNT(*) as total_records,
                AVG(hours_worked) as avg_hours_worked,
                COUNT(CASE WHEN status = 'present' THEN 1 END) as present_days,
                COUNT(CASE WHEN status = 'absent' THEN 1 END) as absent_days,
                COUNT(CASE WHEN status = 'late' THEN 1 END) as late_arrivals
             FROM attendance 
             WHERE YEAR(date) = ? AND MONTH(date) = ?",
            [$year, $month]
        );
        
        return [
            'total_records' => (int)$stats['total_records'],
            'average_hours_worked' => round((float)$stats['avg_hours_worked'], 2),
            'present_days' => (int)$stats['present_days'],
            'absent_days' => (int)$stats['absent_days'],
            'late_arrivals' => (int)$stats['late_arrivals'],
            'attendance_rate' => $stats['total_records'] > 0 ? 
                round(($stats['present_days'] / $stats['total_records']) * 100, 2) : 0
        ];
    }
    
    private function getLeaveStatistics($year, $month) {
        $stats = $this->db->selectOne(
            "SELECT 
                COUNT(*) as total_requests,
                COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved_requests,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_requests,
                SUM(CASE WHEN status = 'approved' THEN days_requested ELSE 0 END) as total_days_approved
             FROM leave_requests 
             WHERE YEAR(start_date) = ? AND MONTH(start_date) = ?",
            [$year, $month]
        );
        
        return [
            'total_requests' => (int)$stats['total_requests'],
            'approved_requests' => (int)$stats['approved_requests'],
            'pending_requests' => (int)$stats['pending_requests'],
            'total_days_approved' => (int)$stats['total_days_approved'],
            'approval_rate' => $stats['total_requests'] > 0 ? 
                round(($stats['approved_requests'] / $stats['total_requests']) * 100, 2) : 0
        ];
    }
    
    private function getPayrollStatistics($year, $month) {
        $stats = $this->db->selectOne(
            "SELECT 
                COUNT(*) as total_payrolls,
                SUM(gross_salary) as total_gross,
                SUM(net_salary) as total_net,
                AVG(gross_salary) as avg_gross_salary,
                AVG(net_salary) as avg_net_salary
             FROM payroll 
             WHERE pay_year = ? AND pay_month = ?",
            [$year, $month]
        );
        
        return [
            'total_payrolls' => (int)$stats['total_payrolls'],
            'total_gross_salary' => round((float)$stats['total_gross'], 2),
            'total_net_salary' => round((float)$stats['total_net'], 2),
            'average_gross_salary' => round((float)$stats['avg_gross_salary'], 2),
            'average_net_salary' => round((float)$stats['avg_net_salary'], 2)
        ];
    }
    
    private function getRecruitmentStatistics($year, $month) {
        $stats = $this->db->selectOne(
            "SELECT 
                COUNT(DISTINCT jp.id) as total_job_postings,
                COUNT(ja.id) as total_applications,
                COUNT(CASE WHEN ja.status = 'hired' THEN 1 END) as successful_hires
             FROM job_postings jp
             LEFT JOIN job_applications ja ON jp.id = ja.job_posting_id
             WHERE YEAR(jp.created_at) = ? AND MONTH(jp.created_at) = ?",
            [$year, $month]
        );
        
        return [
            'total_job_postings' => (int)$stats['total_job_postings'],
            'total_applications' => (int)$stats['total_applications'],
            'successful_hires' => (int)$stats['successful_hires'],
            'hire_rate' => $stats['total_applications'] > 0 ? 
                round(($stats['successful_hires'] / $stats['total_applications']) * 100, 2) : 0
        ];
    }
    
    private function getPerformanceStatistics($year) {
        $stats = $this->db->selectOne(
            "SELECT 
                COUNT(*) as total_reviews,
                AVG(overall_rating) as avg_rating,
                COUNT(CASE WHEN overall_rating >= 4 THEN 1 END) as high_performers
             FROM performance_reviews 
             WHERE review_year = ?",
            [$year]
        );
        
        return [
            'total_reviews' => (int)$stats['total_reviews'],
            'average_rating' => round((float)$stats['avg_rating'], 2),
            'high_performers' => (int)$stats['high_performers'],
            'high_performer_rate' => $stats['total_reviews'] > 0 ? 
                round(($stats['high_performers'] / $stats['total_reviews']) * 100, 2) : 0
        ];
    }
    
    private function getTrainingStatistics($year, $month) {
        // Create training tables if they don't exist
        $this->createTrainingTablesIfNotExist();
        
        $stats = $this->db->selectOne(
            "SELECT 
                COUNT(DISTINCT tp.id) as total_programs,
                COUNT(te.id) as total_enrollments,
                COUNT(CASE WHEN te.status = 'completed' THEN 1 END) as completed_trainings
             FROM training_programs tp
             LEFT JOIN training_enrollments te ON tp.id = te.program_id
             WHERE YEAR(tp.created_at) = ? AND MONTH(tp.created_at) = ?",
            [$year, $month]
        );
        
        return [
            'total_programs' => (int)$stats['total_programs'],
            'total_enrollments' => (int)$stats['total_enrollments'],
            'completed_trainings' => (int)$stats['completed_trainings'],
            'completion_rate' => $stats['total_enrollments'] > 0 ? 
                round(($stats['completed_trainings'] / $stats['total_enrollments']) * 100, 2) : 0
        ];
    }
    
    private function getRecentActivities() {
        $activities = [];
        
        // Recent hires
        $recentHires = $this->db->select(
            "SELECT 'hire' as type, CONCAT(first_name, ' ', last_name) as description, hire_date as date
             FROM employees 
             WHERE hire_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
             ORDER BY hire_date DESC
             LIMIT 5"
        );
        
        // Recent leave requests
        $recentLeaves = $this->db->select(
            "SELECT 'leave' as type, 
                    CONCAT(e.first_name, ' ', e.last_name, ' requested ', lt.name) as description,
                    lr.created_at as date
             FROM leave_requests lr
             JOIN employees e ON lr.employee_id = e.id
             JOIN leave_types lt ON lr.leave_type_id = lt.id
             WHERE lr.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             ORDER BY lr.created_at DESC
             LIMIT 5"
        );
        
        $activities = array_merge($recentHires, $recentLeaves);
        
        // Sort by date
        usort($activities, function($a, $b) {
            return strtotime($b['date']) - strtotime($a['date']);
        });
        
        return array_slice($activities, 0, 10);
    }
    
    private function getHRAlerts() {
        $alerts = [];
        
        // Pending leave requests
        $pendingLeaves = $this->db->selectOne(
            "SELECT COUNT(*) as count FROM leave_requests WHERE status = 'pending'"
        );
        
        if ($pendingLeaves['count'] > 0) {
            $alerts[] = [
                'type' => 'warning',
                'message' => $pendingLeaves['count'] . ' pending leave requests require approval',
                'action_url' => '/leave/requests?status=pending'
            ];
        }
        
        // Employees with no attendance today
        $absentToday = $this->db->selectOne(
            "SELECT COUNT(*) as count 
             FROM employees e
             LEFT JOIN attendance a ON e.id = a.employee_id AND a.date = CURDATE()
             WHERE e.status = 'active' AND a.id IS NULL"
        );
        
        if ($absentToday['count'] > 0) {
            $alerts[] = [
                'type' => 'info',
                'message' => $absentToday['count'] . ' employees have not marked attendance today',
                'action_url' => '/attendance/today'
            ];
        }
        
        // Upcoming performance reviews
        $upcomingReviews = $this->db->selectOne(
            "SELECT COUNT(*) as count 
             FROM employees 
             WHERE status = 'active' 
             AND id NOT IN (
                 SELECT employee_id FROM performance_reviews 
                 WHERE review_year = YEAR(CURDATE())
             )"
        );
        
        if ($upcomingReviews['count'] > 0) {
            $alerts[] = [
                'type' => 'info',
                'message' => $upcomingReviews['count'] . ' employees pending performance review',
                'action_url' => '/performance/reviews'
            ];
        }
        
        return $alerts;
    }
    
    // MIS Report generators
    
    private function generateEmployeeMISReport($dateFrom, $dateTo, $filters) {
        $whereConditions = [];
        $params = [];
        
        if (!empty($filters['department_id'])) {
            $whereConditions[] = "e.department_id = ?";
            $params[] = $filters['department_id'];
        }
        
        if (!empty($filters['status'])) {
            $whereConditions[] = "e.status = ?";
            $params[] = $filters['status'];
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        return $this->db->select(
            "SELECT e.employee_id, e.first_name, e.last_name, e.email, e.phone,
                    d.name as department, p.title as position, e.hire_date, e.status
             FROM employees e
             LEFT JOIN departments d ON e.department_id = d.id
             LEFT JOIN positions p ON e.position_id = p.id
             $whereClause
             ORDER BY e.employee_id",
            $params
        );
    }
    
    private function generateAttendanceMISReport($dateFrom, $dateTo, $filters) {
        $whereConditions = ["a.date BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if (!empty($filters['department_id'])) {
            $whereConditions[] = "e.department_id = ?";
            $params[] = $filters['department_id'];
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        
        return $this->db->select(
            "SELECT e.employee_id, e.first_name, e.last_name, d.name as department,
                    a.date, a.check_in_time, a.check_out_time, a.hours_worked, a.status
             FROM attendance a
             JOIN employees e ON a.employee_id = e.id
             LEFT JOIN departments d ON e.department_id = d.id
             $whereClause
             ORDER BY a.date DESC, e.employee_id",
            $params
        );
    }
    
    private function generatePayrollMISReport($dateFrom, $dateTo, $filters) {
        $whereConditions = ["STR_TO_DATE(CONCAT(p.pay_year, '-', p.pay_month, '-01'), '%Y-%m-%d') BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if (!empty($filters['department_id'])) {
            $whereConditions[] = "e.department_id = ?";
            $params[] = $filters['department_id'];
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        
        return $this->db->select(
            "SELECT e.employee_id, e.first_name, e.last_name, d.name as department,
                    p.pay_year, p.pay_month, p.basic_salary, p.gross_salary, p.net_salary,
                    p.pf_deduction, p.esi_deduction, p.tds_deduction, p.professional_tax
             FROM payroll p
             JOIN employees e ON p.employee_id = e.id
             LEFT JOIN departments d ON e.department_id = d.id
             $whereClause
             ORDER BY p.pay_year DESC, p.pay_month DESC, e.employee_id",
            $params
        );
    }
    
    private function generateLeaveMISReport($dateFrom, $dateTo, $filters) {
        $whereConditions = ["lr.start_date BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if (!empty($filters['department_id'])) {
            $whereConditions[] = "e.department_id = ?";
            $params[] = $filters['department_id'];
        }
        
        if (!empty($filters['leave_type_id'])) {
            $whereConditions[] = "lr.leave_type_id = ?";
            $params[] = $filters['leave_type_id'];
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        
        return $this->db->select(
            "SELECT e.employee_id, e.first_name, e.last_name, d.name as department,
                    lt.name as leave_type, lr.start_date, lr.end_date, lr.days_requested,
                    lr.reason, lr.status, lr.approved_by
             FROM leave_requests lr
             JOIN employees e ON lr.employee_id = e.id
             JOIN leave_types lt ON lr.leave_type_id = lt.id
             LEFT JOIN departments d ON e.department_id = d.id
             $whereClause
             ORDER BY lr.start_date DESC",
            $params
        );
    }
    
    private function generatePerformanceMISReport($dateFrom, $dateTo, $filters) {
        $whereConditions = ["pr.review_date BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if (!empty($filters['department_id'])) {
            $whereConditions[] = "e.department_id = ?";
            $params[] = $filters['department_id'];
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        
        return $this->db->select(
            "SELECT e.employee_id, e.first_name, e.last_name, d.name as department,
                    pr.review_year, pr.review_period, pr.overall_rating, pr.goals_achievement,
                    pr.strengths, pr.areas_for_improvement
             FROM performance_reviews pr
             JOIN employees e ON pr.employee_id = e.id
             LEFT JOIN departments d ON e.department_id = d.id
             $whereClause
             ORDER BY pr.review_date DESC",
            $params
        );
    }
    
    private function generateRecruitmentMISReport($dateFrom, $dateTo, $filters) {
        $whereConditions = ["jp.created_at BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if (!empty($filters['department_id'])) {
            $whereConditions[] = "jp.department_id = ?";
            $params[] = $filters['department_id'];
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        
        return $this->db->select(
            "SELECT jp.title as job_title, d.name as department, jp.status as job_status,
                    ja.applicant_name, ja.email, ja.phone, ja.status as application_status,
                    ja.applied_at
             FROM job_postings jp
             LEFT JOIN job_applications ja ON jp.id = ja.job_posting_id
             LEFT JOIN departments d ON jp.department_id = d.id
             $whereClause
             ORDER BY jp.created_at DESC",
            $params
        );
    }
    
    private function generateTrainingMISReport($dateFrom, $dateTo, $filters) {
        $this->createTrainingTablesIfNotExist();
        
        $whereConditions = ["te.enrolled_at BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if (!empty($filters['department_id'])) {
            $whereConditions[] = "e.department_id = ?";
            $params[] = $filters['department_id'];
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        
        return $this->db->select(
            "SELECT e.employee_id, e.first_name, e.last_name, d.name as department,
                    tp.title as training_program, tp.category, te.enrolled_at, te.completed_at,
                    te.progress_percentage, te.status, te.rating
             FROM training_enrollments te
             JOIN employees e ON te.employee_id = e.id
             JOIN training_programs tp ON te.program_id = tp.id
             LEFT JOIN departments d ON e.department_id = d.id
             $whereClause
             ORDER BY te.enrolled_at DESC",
            $params
        );
    }
    
    private function downloadCSVReport($report) {
        $filename = $report['report_type'] . '_report_' . date('Y-m-d') . '.csv';
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        if (!empty($report['data'])) {
            // Write headers
            fputcsv($output, array_keys($report['data'][0]));
            
            // Write data
            foreach ($report['data'] as $row) {
                fputcsv($output, $row);
            }
        }
        
        fclose($output);
        exit;
    }
    
    private function createTrainingTablesIfNotExist() {
        $query1 = "CREATE TABLE IF NOT EXISTS training_programs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(200) NOT NULL,
            category VARCHAR(50),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        
        $query2 = "CREATE TABLE IF NOT EXISTS training_enrollments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            program_id INT,
            employee_id INT,
            enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP NULL,
            progress_percentage DECIMAL(5,2) DEFAULT 0,
            status VARCHAR(20) DEFAULT 'enrolled',
            rating DECIMAL(3,2)
        )";
        
        $this->db->execute($query1);
        $this->db->execute($query2);
    }
}

?>